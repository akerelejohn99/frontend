
function processForm() {

    var username = document.getElementById('username').value;

    var password = document.getElementById('password').value;

    if(username == ''){
        document.getElementById('error').innerHTML = 'Username is required';
        return false;
    }
    else{
        document.getElementById('error').style.color = 'green';
    }

    if(password == '')
    {
        document.getElementById('error').innerHTML = 'Password is required';
        return false;
    }
    else{
        document.getElementById('error').style.color = 'green';
    }
}


// Assignment

// Check if password has uppercase, lowercase, number and special characters

// Check if password is up tp 8 characters